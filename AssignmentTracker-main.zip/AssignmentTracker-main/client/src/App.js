import React, { Component, useCallback, useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import AddAssignment from "./components/addAssignment";
import helper from "./helpers/mainHelper";
import "./App.css";
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

function App() {
  // let defaultState = {
  //   events: [
  //     {
  //       start: moment().toDate(),
  //       end: moment().add(1, "days").toDate(),
  //       title: "Some title",
  //     },
  //   ],
  // };

  let defaultState = {};

  let [showAdd, handleClick] = useState(false);
  let [state, setState] = useState(defaultState);

  useEffect(() => {
    // console.log("HERE:", await helper.getAssignments());
    // setState(helper.getAssignments());
    const fetchData = async () => {
      try {
        const existingData = await helper.getAssignments();
        let newState = {
          events: JSON.parse(existingData),
        };
        setState(newState);
        console.log(state);
      } catch (e) {
        console.log(e);
      }
    };
    fetchData();
  }, [state]);

  const handleAdd = (newData) => {
    //let eventsJSON = JSON.parse(state).events;
    //setState(JSON.stringify(newData));
    let newState = {
      events: JSON.parse(newData),
    };
    setState(newState);
  };

  //console.log(showAdd);

  return (
    <div className="App">
      <button onClick={() => handleClick((showAdd = true))}>
        Add Assignment
      </button>

      {showAdd && <AddAssignment handleAdd={handleAdd} />}

      <Calendar
        localizer={localizer}
        defaultDate={new Date()}
        // onDoubleClickEvent={handleClick}
        // onSelectSlot={handleClick}
        defaultView="month"
        selectable
        events={state.events}
        style={{ height: "80vh", width: "80vh" }}
      />
    </div>
  );
}

export default App;
