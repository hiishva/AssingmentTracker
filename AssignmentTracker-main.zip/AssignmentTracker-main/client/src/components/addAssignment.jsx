import React from "react";
import moment from "moment";
import helper from "../helpers/mainHelper";

function addAssignment({ handleAdd }) {
  let handleSubmit = async (event) => {
    event.preventDefault();
    let body = {
      start: moment().toDate(),
      end: moment().toDate(),
      title: "ABC Some new title",
      priority: 1,
    };
    try {
      let response = await helper.addAssignmentFunction(body);
      handleAdd(response);
    } catch (e) {
      console.log(e);
    }
  };

  // function handleSubmit(event) {
  //   let body = {
  //     title: "Sample Assignemnt",
  //     priority: "1",
  //     date: "2022-11-18",
  //   };
  //   let response = helper.addAssignmentFunction(body);
  //   console.log(response);
  //   props.func(response);
  // }

  return (
    <>
      <h1>Add Assignment</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Assignment Name:
          <input type="text" name="name" />
          Priority:
          <input type="text" name="prit" />
          Date:
          <input
            type="date"
            id="start"
            name="trip-start"
            value="2022-11-25"
            min="2022-11-01"
            max="2022-12-31"
          ></input>
        </label>
        <input type="submit" value="Submit" />
      </form>
    </>
  );
}

export default addAssignment;
