import axios from "axios";

const addAssignmentFunction = async (body) => {
  let response;

  const options = {
    method: "POST",
    data: body,
    url: "http://localhost:3001/add-assignment",
  };

  try {
    response = await axios(options);
  } catch (err) {
    console.log(err);
  }

  return response.data;
};

const getAssignments = async () => {
  const options = {
    method: "GET",
    url: "http://localhost:3001/get-all-assignments",
  };

  let response;
  try {
    response = await axios(options);
  } catch (err) {
    console.log(err);
  }
  return response.data;
};

const helper = {
  getAssignments,
  addAssignmentFunction,
};

export default helper;
