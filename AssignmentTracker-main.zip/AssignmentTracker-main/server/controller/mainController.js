const fs = require("fs");
const path = require("path");

exports.addAssignment = async (req, res, next) => {
  let assignment = req.body;

  let assignmentData = JSON.parse(
    fs.readFileSync(path.resolve(__dirname, "../database/assignment.json"))
  );

  assignmentData.push(assignment);

  let newData = JSON.stringify(assignmentData);
  fs.writeFileSync(
    path.resolve(__dirname, "../database/assignment.json"),
    newData
  );

  res.status(200).json(newData);
};

exports.home = async (req, res, next) => {
  res.status(200).json({ data: "Sup from the server, loser" });
};

exports.getAllAssignments = async (req, res, next) => {
  let data = JSON.parse(
    fs.readFileSync(path.resolve(__dirname, "../database/assignment.json"))
  );
  console.log(JSON.stringify(data));
  res.status(200).json(JSON.stringify(data));
};
