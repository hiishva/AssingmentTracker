const express = require("express");
const mainRouter = express.Router();
const controller = require("../controller/mainController");

mainRouter.route("/add-assignment").post(controller.addAssignment);
mainRouter.route("/get-all-assignments").get(controller.getAllAssignments);
mainRouter.route("/").get(controller.home);
module.exports = mainRouter;
